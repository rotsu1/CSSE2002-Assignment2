package sheep.games.snake;

import sheep.expression.TypeError;
import sheep.expression.basic.Constant;
import sheep.expression.basic.Nothing;
import sheep.features.Feature;
import sheep.games.game.Game;
import sheep.games.game.GameStart;
import sheep.games.game.MoveCell;
import sheep.games.random.RandomCell;
import sheep.games.game.Move;
import sheep.sheets.CellLocation;
import sheep.sheets.Sheet;
import sheep.ui.Perform;
import sheep.ui.Prompt;
import sheep.ui.Tick;
import sheep.ui.UI;

import java.util.ArrayList;
import java.util.List;

public class Snake implements Tick, Feature, Game, MoveCell {

    private boolean started = false;

    private List<CellLocation> snake = new ArrayList<>();

    private List<CellLocation> food = new ArrayList<>();

    private Sheet sheet;

    private int direction = -2;

    private CellLocation snakeHead;

    private boolean ate = false;

    public final RandomCell randomcell;

    public Snake(Sheet sheet, RandomCell randomcell) {
        this.sheet = sheet;
        this.randomcell = randomcell;
    }

    @Override
    public void register(UI ui) {
        ui.onTick(this);
        ui.addFeature("snake", "Snake game", getStart());
        ui.onKey("a", "Move Left", getMove(-1));
        ui.onKey("d", "Move Right", getMove(1));
        ui.onKey("w", "Move Up", getMove(2));
        ui.onKey("s", "Move Down", getMove(-2));
    }

    @Override
    public void startGame(int row, int column) {
        started = true;
        getCurrentSheet();
        if (snake.isEmpty()) {
            try {
                sheet.update(new CellLocation(row, column), new Constant(1));
            } catch (TypeError e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void endGame() {
        started = false;
    }

    @Override
    public boolean onTick(Prompt prompt) {
        if (!started) {
            return false;
        }
        getCurrentSheet();
        if (ate) {
            if (!grow()) {
                gameOver(prompt);
            }
            return true;
        }
        if (!move()) {
            gameOver(prompt);
        }
        return true;
    }

    @Override
    public void shift(int direction) {
        this.direction = direction;
    }

    public void gameOver(Prompt prompt) {
        prompt.message("Game Over!");
        started = false;
    }

    public boolean inBounds(List<CellLocation> locations) {
        for (CellLocation location : locations) {
            if (!sheet.contains(location)) {
                return false;
            }
        }
        return true;
    }

    public boolean move() {
        if (!started) {
            return false;
        }
        clear(snake);
        clear(food);

        snakeHead = snake.getLast();
        int row = snakeHead.getRow();
        int column = snakeHead.getColumn();
        CellLocation newHead = new CellLocation(row + getRowShift(), column + getColumnShift());

        snake.add(newHead);
        snake.removeFirst();

        if (food.contains(newHead)) {
            ate = true;
            newFood();
            food.remove(newHead);
        }

        if (!inBounds(snake)) {
            return false;
        }

        render(food, 2);
        render(snake, 1);
        return true;
    }

    private int getColumnShift() {
        if (direction == -1 || direction == 1) {
            return direction;
        }
        return 0;
    }

    private int getRowShift() {
        if (direction == -2) {
            return 1;
        } else if(direction == 2) {
            return -1;
        }
        return 0;
    }

    public boolean grow() {
        clear(snake);
        clear(food);
        snakeHead = snake.getLast();
        int row = snakeHead.getRow() + getRowShift();
        int column = snakeHead.getColumn() + getColumnShift();

        CellLocation newHead = new CellLocation(row, column);
        snake.add(newHead);

        if (!inBounds(snake)) {
            snake.removeLast();
            if (row == -1) {
                row = sheet.getRows() - 1;
            } else if (row == sheet.getRows()) {
                row = 0;
            } else if (column == -1) {
                column = sheet.getColumns() - 1;
            } else if (column == sheet.getColumns()) {
                column = 0;
            }
            newHead = new CellLocation(row, column);
            snake.add(newHead);
        }

        food.remove(snakeHead);
        if (ate) {
            newFood();
        }
        render(food, 2);
        render(snake, 1);
        ate = food.contains(newHead);
        return true;
    }

    private void newFood() {
        CellLocation newFood = randomcell.pick();
        if (snake.contains(newFood)) {
            return;
        }
        food.add(newFood);
    }

    /**
     * Clears the sheet.
     */
    public void clear(List<CellLocation> items) {
        for (CellLocation cell : items) {
            try {
                sheet.update(cell, new Nothing());
            } catch (TypeError e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * Recreates the sheet with the updated content.
     * @param items The updated content.
     */
    public void render(List<CellLocation> items, int object) {
        for (CellLocation cell : items) {
            try {
                sheet.update(cell, new Constant(object));
            } catch (TypeError e) {
                throw new RuntimeException(e);
            }
        }
    }

    public Perform getStart() {
        return new GameStart<Snake>(this);
    }

    public Perform getMove(int direction) {
        return new Move<Snake>(direction, this);
    }

    public void getCurrentSheet() {
        for (int row = 0; row < sheet.getRows(); row ++) {
            for (int column = 0; column < sheet.getColumns(); column++) {
                String content = sheet.valueAt(row, column).getContent();
                CellLocation location = new CellLocation(row, column);
                if (!snake.contains(location) && !food.contains(location)) {
                    if (content.equals("1")) {
                        snake.add(new CellLocation(row, column));
                    } else if (content.equals("2")) {
                        food.add(new CellLocation(row, column));
                    }
                }
            }
        }
    }
}
