package sheep.features;

import sheep.ui.UI;

public interface Feature {
    void register(UI ui);
}
