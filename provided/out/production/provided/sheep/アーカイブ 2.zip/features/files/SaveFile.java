package sheep.features.files;

import sheep.features.files.FileSaving;
import sheep.ui.Perform;
import sheep.ui.Prompt;

import java.util.Optional;

public class SaveFile implements Perform {

    private FileSaving fileSave;

    public SaveFile(FileSaving fileSave) {
        this.fileSave = fileSave;
    }
    @Override
    public void perform(int row, int column, Prompt prompt) {
//        Optional<String> optFilename = prompt.ask("File name");
//        String filename = optFilename.stream()
//                .filter(x -> x.length() == 1)
//                .findFirst()  // returns Optional
//                .map(Object::toString)
//                .orElse("");
        Optional<String> filename = prompt.ask("File Name");
        filename.ifPresent(s -> fileSave.save(s));
    }

}
