package sheep.features.files;

import sheep.features.files.FileLoading;
import sheep.ui.Perform;
import sheep.ui.Prompt;

public class LoadFile implements Perform {

    private FileLoading fileLoading;

    public LoadFile(FileLoading fileLoading) {
        this.fileLoading = fileLoading;
    }

    @Override
    public void perform(int row, int column, Prompt prompt) {
        if (!fileLoading.load(String.valueOf(prompt.ask("Filename")))) {
            prompt.message("Unable to load file");
        }
    }

}
