package sheep.features.files;

import sheep.features.files.FileSaving;
import sheep.ui.Perform;
import sheep.ui.Prompt;

public class SaveFile implements Perform {

    private FileSaving fileSave;

    public SaveFile(FileSaving fileSave) {
        this.fileSave = fileSave;
    }
    @Override
    public void perform(int row, int column, Prompt prompt) {
        fileSave.save(String.valueOf(prompt.ask("File name")));
    }

}
