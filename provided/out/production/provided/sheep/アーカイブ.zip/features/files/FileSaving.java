package sheep.features.files;

import sheep.features.Feature;
import sheep.sheets.Sheet;
import sheep.ui.UI;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringJoiner;

public class FileSaving implements Feature {

    private Sheet sheet;

    public FileSaving(Sheet sheet) {
        this.sheet = sheet;
    }

    public void register(UI ui ) {
        ui.addFeature("save-file", "Save file", getSave());
    }

    public SaveFile getSave() {
        return new SaveFile(this);
    }

    public void save(String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter((filename)))) {
            writer.write(this.toString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String toString() {
        StringJoiner res = new StringJoiner(System.lineSeparator());

        int rowSize = sheet.getRows();
        int columnSize = sheet.getColumns();
        res.add(Integer.toString(rowSize));
        res.add(Integer.toString(columnSize));

        for (int row = 0; row < rowSize; row++) {
            for (int column = 0; column < columnSize; column++) {
                String value = sheet.valueAt(row, column).getContent();
                if (!value.isEmpty()) {
                    String cell = row + "|" + column + "|" + value;
                    res.add(cell);
                }
            }
        }

        return res.toString();
    }
    /*
    Store row and column.
    Loop through the sheet and if there is a value, store that as well.
    Map<CellLocation, String> where there the string is the value inside the cell.

     */
}
