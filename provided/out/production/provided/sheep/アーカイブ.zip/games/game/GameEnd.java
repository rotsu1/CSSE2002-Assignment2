package sheep.games.game;

import sheep.games.game.Game;
import sheep.ui.Perform;
import sheep.ui.Prompt;

/**
 * A class that ends the game.
 */
public class GameEnd<T extends Game> implements Perform {

    /**
     * Reference to the game.
     */
    private T game;

    /**
     * Constructor
     * @param game reference to the game.
     */
    public GameEnd(T game) {
        this.game = game;
    }

    @Override
    public void perform(int row, int column, Prompt prompt) {
        game.endGame();
    }
}
