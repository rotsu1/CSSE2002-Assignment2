package sheep.games.game;

public interface MoveCell {
    void shift(int direction);
}
